ALTER TABLE laptops
CHANGE COLUMN `disco-duro` disco_duro VARCHAR(45) NOT NULL;
