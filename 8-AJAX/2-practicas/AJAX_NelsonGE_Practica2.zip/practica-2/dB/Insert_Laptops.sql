use equipos;

INSERT INTO `equipos`.`laptops` (`marca`, `categoria`, `modelo`, `memoria`, `disco-duro`)
VALUES
("Dell", "Inspiron", "3525", "16GB", "500GB"),
("Dell", "Inspiron", "3520", "8GB", "256GB"),
("Dell", "G15", "5530", "16GB", "500GB"),
("Dell", "G15", "5525", "8GB", "256GB"),
("Dell", "Latitude", "3420", "16GB", "500GB");
