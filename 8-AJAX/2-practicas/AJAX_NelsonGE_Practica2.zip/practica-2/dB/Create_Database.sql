CREATE DATABASE equipos;
use equipos;