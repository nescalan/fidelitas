<?php // cofig.php


$bd_config = [
    'host' => 'localhost',
    'user' => 'root',
    'pwd' => '4u3p7px6',
    'db' => 'ejercicio2'
];

?>