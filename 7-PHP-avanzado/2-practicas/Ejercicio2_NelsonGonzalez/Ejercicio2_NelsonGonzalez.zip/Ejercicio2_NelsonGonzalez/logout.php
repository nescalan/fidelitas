<?php // logout.php

require_once 'index.php';

?>