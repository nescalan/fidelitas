function setPurchasedProduct() {
  alert("This product is already in the shopping cart !!!");
}
function setThanks() {
  alert("Thanks for your purchase !!!");
}
