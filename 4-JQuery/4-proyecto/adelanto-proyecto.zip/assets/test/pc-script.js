$(document).ready(() => {});
