<?php #index.php

require_once "./actividad.php";

?>