<?php #registrar-visita.php

require_once "./src/views/registrar-visita.view.php";

?>