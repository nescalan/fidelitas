<?php

$serverName = "localhost";
$user = "root";
$password = "1234";
$bdName = "NombreBD";

function IniciarConexion(){

}

function cerrarConexion(){

}

?>