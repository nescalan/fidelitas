let firstName, lastName, age;

firstName = prompt("Insert your first name: ");
lastName = prompt("Insert your last name: ");
age = prompt("Insert your age: ");
alert(`El nombre ingresado es ${firstName} ${lastName} y tiene ${age} años`);
