for (let index = 0; index <= 10; index++) {
  if (index % 2 == 0 && index != 0) {
    alert(index);
  }
}
