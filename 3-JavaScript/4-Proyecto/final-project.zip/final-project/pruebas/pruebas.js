array = [
  "Cheese Pizza",
  "Pepperoni Pizza",
  "Vegetarian Pizza",
  "Rustica Pizza",
  "Delicious Pizza",
  "Tomato Pizza",
];

for (let index = 0; index < array.length; index++) {
  let element = array[index];
  console.log(element);
}
