// Declaracion de variables
let admin, nombre;

// Asignar el valor a nombre
nombre = "Nelson GE";

// Copiar contenido de nombre a admin
admin = nombre;

// Muestra el valor de admin usando alert
alert("El nombre usado es: " + admin);
