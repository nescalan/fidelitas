"use strict";

let monthlySales = ["Google", "Samsung", "Apple", "Xiaomi", "Huawei", "Honor"];
document.write(`Primer Lugar: ${monthlySales[0]} <br>`);
document.write(`Segundo Lugar: ${monthlySales[1]} <br>`);
document.write(`Tercer Lugar: ${monthlySales[2]} <br>`);
document.write(`Cuarto Lugar: ${monthlySales[3]} <br>`);
document.write(`Quinto Lugar: ${monthlySales[4]} <br>`);
document.write(`Sexto Lugar: ${monthlySales[5]} <br>`);
